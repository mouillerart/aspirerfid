package org.ow2.aspirerfid.ide.bpwme.diagram.edit.helpers;

/**
 * @generated
 */
public class ConnectionEditHelper extends BpwmeBaseEditHelper {
}
