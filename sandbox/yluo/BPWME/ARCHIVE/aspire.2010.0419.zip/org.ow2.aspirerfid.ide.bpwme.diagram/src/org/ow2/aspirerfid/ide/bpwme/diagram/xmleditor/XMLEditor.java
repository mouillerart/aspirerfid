package org.ow2.aspirerfid.ide.bpwme.diagram.xmleditor;

import org.ow2.aspirerfid.ide.bpwme.diagram.simpleditor.SimpleEditor;


public class XMLEditor extends SimpleEditor {

	public static String ID = "bpwme.diagram.xmleditor.XMLEditor";
	private ColorManager colorManager;

	protected void internal_init() {
		configureInsertMode(SMART_INSERT, false);
		colorManager = new ColorManager();
		setSourceViewerConfiguration(new XMLConfiguration(colorManager));
		setDocumentProvider(new XMLDocumentProvider());
	}
	
	public void dispose() {
		colorManager.dispose();
		super.dispose();
	}
}
