package org.ow2.aspirerfid.ide.bpwme.utils;

import org.ow2.aspirerfid.commons.apdl.model.CLCBProc;
import org.ow2.aspirerfid.commons.apdl.model.EBProc;
import org.ow2.aspirerfid.commons.apdl.model.OLCBProc;


/**
 * A class for retrieving olcb, clcb and ebproc
 * Model from main memory by id
 * 
 * @author Yongming Luo <yluo@ait.edu.gr>
 *
 */
public class OLCBProcAssistant {
	private OLCBProc olcb;
	
	/**
	 * Constructor, bind the assistant with an existing olcb
	 * @param olcb - the root OLCB Process
	 */
	public OLCBProcAssistant(OLCBProc olcb) {
		this.olcb = olcb;
	}
	
	/**
	 * Get the specific CLCB Proc by id
	 * id should be unique in system
	 * @param id
	 * @return CLCB Proc with the specific id
	 */
	public CLCBProc getCLCB(String id) {
		for (CLCBProc clcb : olcb.getCLCBProc()) {
			if(clcb.getId().equals(id)) {
				return clcb;
			}
		}
		return null;
	}
	
	/**
	 * Get the specific EBProc by id and its parent CLCBProc
	 * id should be unique in system
	 * the parent CLCBProc is used to accelerate search
	 * @param clcb
	 * @param id
	 * @return
	 */
	public EBProc getEBProc(CLCBProc clcb, String id) {
		for (EBProc ebp : clcb.getEBProc()) {
			if(ebp.getId().equals(id)) {
				return ebp;
			}
		}
		return null;
	}
}
