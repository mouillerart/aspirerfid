package org.ow2.aspirerfid.ide.bpwme.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Vector;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gmf.runtime.notation.View;
import org.ow2.aspirerfid.commons.apdl.model.OLCBProc;
import org.ow2.aspirerfid.commons.apdl.model.ObjectFactory;
import org.ow2.aspirerfid.commons.apdl.utils.DeserializerUtil;
import org.ow2.aspirerfid.commons.apdl.utils.Serializer;
import org.ow2.aspirerfid.ide.bpwme.CLCBProc;
import org.ow2.aspirerfid.ide.bpwme.EBProc;
import org.ow2.aspirerfid.ide.bpwme.diagram.edit.parts.OLCBProcEditPart;
import org.ow2.aspirerfid.ide.bpwme.diagram.edit.parts.WorkflowMapEditPart;
import org.ow2.aspirerfid.ide.bpwme.diagram.simpleditor.PathEditorInput;
import org.ow2.aspirerfid.ide.bpwme.diagram.simpleditor.SimpleEditor;
import org.ow2.aspirerfid.ide.bpwme.ecspec.model.ExtraProperty;
import org.ow2.aspirerfid.ide.bpwme.ecspec.utils.ECSpecBuilder;
import org.ow2.aspirerfid.ide.bpwme.ecspec.utils.LRSpecBuilder;
import org.ow2.aspirerfid.ide.bpwme.ecspec.views.ECSpecEditor;
import org.ow2.aspirerfid.ide.bpwme.impl.OLCBProcImpl;

/**
 * Basic hack class do the dirty work
 * Singleton pattern to return the instance anywhere
 * 
 * @author Yongming Luo <yluo@ait.edu.gr>
 *
 */

public class MainControl {
	/**
	 * FileAction is to record what is the most recent
	 * action of the user, open a file or create a new file.
	 * If it's open a file, should do the model binding work.
	 * If it's create a new file, don't do these things.
	 */
	public enum FileAction{
		NewAction, OpenAction
	}
	
	/**
	 * Four event types for user to select.
	 * TODO may change the relative operations after creating
	 * master data editor.
	 * 
	 */
	public enum EventType{
		OBJECT_EVENT,AGGREGATION_EVENT,QUANTITY_EVENT,TRANSACTION_EVENT
	}
	
	private static MainControl mainControl;
	private static String fileSeparator =
		System.getProperty("file.separator");
	private static String userHome = System.getProperty("user.home");
	//the folder that apdl xml file should reside in
	private static final String P_PE_ApdlFilesPath =
		userHome+fileSeparator+"AspireRFID"+fileSeparator+"IDE"+fileSeparator
		+"APDLs"+fileSeparator;
	//apdl file uri
	private URI apdlURI;
	//assistant file path. assistant file now is to record
	//the event type of each ebproc
	private String assistantPath; 
	private FileAction fa;

	private OLCBProc olcbProc;
	//private EBProc selectedEbProc;
	public LRSpecBuilder lrsb;
	public ECSpecBuilder ecsb;
	//private SimpleEditor simpleEditor;
	public ObjectFactory objectFactory;
	private HashMap<Integer, Object> objectMap;
	public HashMap<String, EventType> ebprocMap;
	public ECSpecEditor ecEditor;
	public WorkflowMapEditPart wme;
	public OLCBProcEditPart olcbep;
	
	
	public Vector<ExtraProperty> extraLLRPProperty;
	public Vector<ExtraProperty> extraRPProperty;
	public Vector<ExtraProperty> extraHALProperty;



	public MainControl() throws Exception {
		//create apdl file directory if it's not exist
		File directory = new File(P_PE_ApdlFilesPath);
		if(!directory.exists()) {
			directory.mkdirs();
		}
		
		//initialization for some objects
		objectFactory = new ObjectFactory();
		objectMap = new HashMap<Integer, Object>();
		ebprocMap = new HashMap<String, EventType>();
		extraLLRPProperty = new Vector<ExtraProperty>();
		extraRPProperty = new Vector<ExtraProperty>();
		extraHALProperty = new Vector<ExtraProperty>();

		extraLLRPProperty.add(new ExtraProperty("ConnectionPointAddress",ExtraProperty.LLRP_TYPE));
		extraLLRPProperty.add(new ExtraProperty("ConnectionPointPort",ExtraProperty.LLRP_TYPE));
		extraLLRPProperty.add(new ExtraProperty("PhysicalReaderSource",ExtraProperty.LLRP_TYPE));
		extraLLRPProperty.add(new ExtraProperty("RoSpecID",ExtraProperty.LLRP_TYPE));

		extraRPProperty.add(new ExtraProperty("ConnectionPointAddress",ExtraProperty.RP_TYPE));
		extraRPProperty.add(new ExtraProperty("ConnectionPointPort",ExtraProperty.RP_TYPE));
		extraRPProperty.add(new ExtraProperty("PhysicalReaderSource",ExtraProperty.RP_TYPE));
		extraRPProperty.add(new ExtraProperty("RoSpecID",ExtraProperty.RP_TYPE));
	}



	/**
	 * From diagram URI get Apdl URI.
	 * Also create the assistant file under the same directory.
	 * @param diagramFileURI
	 */
	public void setAPDLFileName(URI diagramFileURI) {
		String dot = "\\.";
		String[] names = diagramFileURI.lastSegment().split(dot);
		if(names.length == 2) {
			apdlURI = URI.createFileURI(P_PE_ApdlFilesPath+names[0]+".xml");
			File f = new File(apdlURI.toFileString());		
			if(!f.exists()) {
				try {
					f.createNewFile();
				} catch (IOException e) {
						e.printStackTrace();
				}
			}
			
			IPath location= new Path(f.getAbsolutePath());
			PathEditorInput input= new PathEditorInput(location);
			SimpleEditor.setEditorInput(input);
			
			URI apdlAssistant = URI.createFileURI(P_PE_ApdlFilesPath+names[0]+".assistant.xml");
			assistantPath = apdlAssistant.toFileString();
			System.out.println("assistant:" + assistantPath);
		} else {
			System.err.println("Error in MainControl.getFileName");
		}
	}
	
	/**
	 * Rebuild the in memory models from the existing apdl file.
	 */
	public void rebuild() {
		FileInputStream inputStream;
		try {
			MainControl mc = MainControl.getMainControl();
			inputStream = new FileInputStream(mc.getApdlURI().toFileString());
			mc.olcbProc = DeserializerUtil.deserializeOLCBProc(inputStream);
			inputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public OLCBProc createOLCBProc() {
		//1. create object
		olcbProc = objectFactory.createOLCBProc();
		//2. save it to file
		saveObject();
		return olcbProc;
	}
	
	public org.ow2.aspirerfid.commons.apdl.model.CLCBProc createCLCBProc() {
		org.ow2.aspirerfid.commons.apdl.model.CLCBProc clcbProc= objectFactory.createCLCBProc();
		olcbProc.getCLCBProc().add(clcbProc);
		saveObject();
		return clcbProc;
	}

	public org.ow2.aspirerfid.commons.apdl.model.EBProc createEBProc(org.ow2.aspirerfid.commons.apdl.model.CLCBProc clcb) {
		org.ow2.aspirerfid.commons.apdl.model.EBProc ebproc = objectFactory.createEBProc();
		clcb.getEBProc().add(ebproc);
		ebproc.setApdlDataFields(objectFactory.createApdlDataFields());
		saveObject();
		return ebproc;
	}

	public boolean removeCLCBProc(org.ow2.aspirerfid.commons.apdl.model.CLCBProc clcb) {
		boolean result = olcbProc.getCLCBProc().remove(clcb);
		saveObject();
		return result;
	}

	/**
	 * Use a new thread to serialize the model.
	 * Let the program work in parallel.
	 */
	public void saveObject() {
		new WriteToFile(olcbProc).start();
	}

	/**
	 * Map the diagram to the logical model (both in memory).
	 * This method should be called only after the diagram is initialized.
	 * We call it in "OpenDiagram" after the diagram is opened by an editor.
	 */
	public void mapModels() {
		//1. from diagram get the logical model
		OLCBProcImpl opi = (OLCBProcImpl)((View)olcbep.getModel()).getElement();
		//2. from apdl file get the real model
		OLCBProc op = olcbProc;
		OLCBProcAssistant oa = new OLCBProcAssistant(op);
		//3. do the model mapping by id
		objectMap.clear();
		if(!opi.getId().equals(op.getId())) {
			System.err.println("Wrong Mapping in MC.mapModels()");
			return;
		}
		addMap(opi.hashCode(), op);
		for(CLCBProc cpi : opi.getCLCBProc()) {
			org.ow2.aspirerfid.commons.apdl.model.CLCBProc cp;
			if((cp = oa.getCLCB(cpi.getId())) != null) {
				addMap(cpi.hashCode(), cp);
				for(EBProc ebi : cpi.getEBProc()) {
					org.ow2.aspirerfid.commons.apdl.model.EBProc ep;
					if((ep = oa.getEBProc(cp, ebi.getId())) != null) {
						addMap(ebi.hashCode(), ep);
					}else {
						System.err.println("Wrong Mapping in MC.mapModels()");
						return;
					}
				}
			}else {
				System.err.println("Wrong Mapping");
				return;
			}
		}
	}
	
	
	public OLCBProc getOLCBProc() {
		return olcbProc;
	}

	public void setOLCBProc(OLCBProc olcbProc) {
		this.olcbProc = olcbProc;
	}
	
	public void addMap(int hashCode, Object object) {
		objectMap.put(hashCode, object);
	}
	public void delMap(int hashCode) {
		objectMap.remove(hashCode);
	}
	public Object getMapObject(int hashCode) {
		return objectMap.get(hashCode);
	}

	public void getSimpleEditor() {
		SimpleEditor.getEditor();
	}

	public static MainControl getMainControl() {
		if(mainControl == null) {
			try {
				mainControl = new MainControl();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return mainControl;
	}

	public URI getApdlURI() {
		return apdlURI;
	}
	
	public void saveAssistantFile() {
		try {
			FileOutputStream fout = new FileOutputStream(assistantPath);
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			oos.writeObject(ebprocMap);
			oos.close();
		}
		catch (Exception e) { e.printStackTrace();
		} 
	}
	
	public void loadAssistantFile() {
		try {
			FileInputStream fin = new FileInputStream(assistantPath);
			ObjectInputStream ois = new ObjectInputStream(fin);
			ebprocMap = (HashMap<String, EventType>) ois.readObject();
			ois.close();
		}
		catch (Exception e) {
			e.printStackTrace(); 		
		}
	}
	
	public void setFileAction(FileAction fa) {
		this.fa = fa;
	}
	
	public FileAction getFileAction() {
		return fa;
	}
}

/**
 * A new thread to write the OLCB Process to file.
 * It's needed because it may take some time.
 * @author Yongming Luo
 *
 */
class WriteToFile extends Thread {
	OLCBProc olcbProc;
	public WriteToFile(OLCBProc olcbProc) {
		this.olcbProc = olcbProc;
	}
	@Override
	public void run() {
		super.run();
		FileWriter fw;
		try {
			MainControl mc = MainControl.getMainControl();
			fw = new FileWriter(mc.getApdlURI().toFileString());
			Serializer.serializeOLCBProc(olcbProc, fw);
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
