package org.ow2.aspirerfid.ide.bpwme.diagram.edit.helpers;

import org.eclipse.gmf.runtime.common.core.command.ICommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class CLCBProcEditHelper extends BpwmeBaseEditHelper {
}
