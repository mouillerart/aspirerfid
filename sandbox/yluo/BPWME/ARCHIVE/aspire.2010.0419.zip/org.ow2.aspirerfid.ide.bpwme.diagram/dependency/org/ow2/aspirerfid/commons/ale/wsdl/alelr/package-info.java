@javax.xml.bind.annotation.XmlSchema(namespace = "urn:epcglobal:alelr:wsdl:1")
package org.ow2.aspirerfid.commons.ale.wsdl.alelr;
