package org.ow2.aspirerfid.ide.bpwme.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

}
