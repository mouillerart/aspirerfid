package org.ow2.aspirerfid.ide.bpwme.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;


import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.ow2.aspirerfid.ide.bpwme.BpwmePackage;
import org.ow2.aspirerfid.ide.bpwme.diagram.edit.parts.CLCBProcDescriptionEditPart;
import org.ow2.aspirerfid.ide.bpwme.diagram.edit.parts.EBProcDescriptionEditPart;
import org.ow2.aspirerfid.ide.bpwme.diagram.edit.parts.OLCBProcNameEditPart;
import org.ow2.aspirerfid.ide.bpwme.diagram.parsers.MessageFormatParser;
import org.ow2.aspirerfid.ide.bpwme.diagram.part.BpwmeVisualIDRegistry;
/**
 * @generated
 */
public class BpwmeParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser oLCBProcName_5003Parser;

	/**
	 * @generated
	 */
	private IParser getOLCBProcName_5003Parser() {
		if (oLCBProcName_5003Parser == null) {
			EAttribute[] features = new EAttribute[] { BpwmePackage.eINSTANCE
					.getOLCBProc_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			oLCBProcName_5003Parser = parser;
		}
		return oLCBProcName_5003Parser;
	}

	/**
	 * @generated
	 */
	private IParser cLCBProcName_5002Parser;

	/**
	 * @generated
	 */
	private IParser getCLCBProcName_5002Parser() {
		if (cLCBProcName_5002Parser == null) {
			EAttribute[] features = new EAttribute[] { BpwmePackage.eINSTANCE
					.getCLCBProc_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			cLCBProcName_5002Parser = parser;
		}
		return cLCBProcName_5002Parser;
	}

	/**
	 * @generated
	 */
	private IParser eBProcName_5001Parser;

	/**
	 * @generated
	 */
	private IParser getEBProcName_5001Parser() {
		if (eBProcName_5001Parser == null) {
			EAttribute[] features = new EAttribute[] { BpwmePackage.eINSTANCE
					.getEBProc_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			eBProcName_5001Parser = parser;
		}
		return eBProcName_5001Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case OLCBProcNameEditPart.VISUAL_ID:
			return getOLCBProcName_5003Parser();
		case CLCBProcDescriptionEditPart.VISUAL_ID:
			return getCLCBProcName_5002Parser();
		case EBProcDescriptionEditPart.VISUAL_ID:
			return getEBProcName_5001Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(BpwmeVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(BpwmeVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (BpwmeElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
