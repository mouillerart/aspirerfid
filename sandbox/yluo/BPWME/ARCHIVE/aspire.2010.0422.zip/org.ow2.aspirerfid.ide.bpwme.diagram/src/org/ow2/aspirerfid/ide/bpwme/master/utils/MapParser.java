package org.ow2.aspirerfid.ide.bpwme.master.utils;

import java.util.HashMap;

/**
 * From the HashMap get a new object
 * this is the very first edition
 * @author Yongming Luo
 */
public class MapParser {
	public Object parse(HashMap h) {
		for(String s : h.keySet()) {
			HashMap hm = h.get(s);
			for(String st : hm.keySet()) {
				hm.get(st);
			}
		}
	}	
}
