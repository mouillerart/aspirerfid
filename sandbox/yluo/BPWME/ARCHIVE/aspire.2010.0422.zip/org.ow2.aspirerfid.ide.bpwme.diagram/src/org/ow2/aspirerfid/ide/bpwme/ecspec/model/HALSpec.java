package org.ow2.aspirerfid.ide.bpwme.ecspec.model;

import org.ow2.aspirerfid.commons.ale.model.alelr.LRProperty;
import org.ow2.aspirerfid.commons.apdl.model.ApdlDataField;
import org.ow2.aspirerfid.ide.bpwme.ecspec.model.Spec.Type;

public class HALSpec extends Spec{
	public HALSpec(String name) {
		super(name);
		type = Type.HAL;
		iniHAL();
	}
	
	public HALSpec(ApdlDataField adf) {
		super(adf);
		type = Type.HAL;
	}
	
	private void iniHAL() {
		LRProperty lrp = new LRProperty();
		lrp.setName("Description");
		lrp.setValue("A HAL Description");
		adf.getLRSpec().getProperties().getProperty().add(lrp);
	}
	
	public HALSpec getClone() {
		HALSpec newSpec = new HALSpec(this.getName());
		newSpec.adf.getLRSpec().getProperties().getProperty().clear();
		for(LRProperty lrp:adf.getLRSpec().getProperties().getProperty()) {
			newSpec.adf.getLRSpec().getProperties().getProperty().add(cloneLRProperty(lrp));
		}
		return newSpec;
	}

}
