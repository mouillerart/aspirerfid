package org.ow2.aspirerfid.ide.bpwme.master.views;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;
import org.eclipse.ui.views.properties.tabbed.ITabbedPropertySheetPageContributor;

/**
 * Master Editor edit master data.
 * Now this is the very first draft of it.
 * @author Yongming Luo
 */

public class MasterEditor extends EditorPart implements 
ITabbedPropertySheetPageContributor{
	public static final String ID = "org.ow2.aspirerfid.ide.bpwme.master.views.MasterEditor";
	protected boolean isdirty = false;
	@Override
	public void doSave(IProgressMonitor monitor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doSaveAs() {
		doSave(null);
	}

	@Override
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
        setSite(site);       
        setInput(input);
	}

	@Override
	public boolean isDirty() {
		return isdirty;
	}

	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}

	@Override
	public void createPartControl(Composite parent) {
		final ScrolledComposite scrolledComposite = new ScrolledComposite(parent, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);

		final Composite composite = new Composite(scrolledComposite, SWT.NONE);
		composite.setLayout(new GridLayout());
		scrolledComposite.setContent(composite);
		
		CTabFolder tabFolder = new CTabFolder(composite, SWT.TOP);
		tabFolder.setMaximized(true);
		tabFolder.setBorderVisible(true);
		tabFolder.setLayoutData(new GridData(GridData.FILL_BOTH));
		tabFolder.setBackground(null);
		
		CTabItem ctiDisposition = new CTabItem(tabFolder, SWT.NONE);
		ctiDisposition.setText("Disposition");
		Composite compositeDisposition = new Composite(tabFolder, SWT.NONE);
		compositeDisposition.setLayout(new GridLayout());
		compositeDisposition.setLayoutData(new GridData(GridData.FILL_BOTH));
		ctiDisposition.setControl(compositeDisposition);
		
		
		CTabItem ctiBizStep = new CTabItem(tabFolder, SWT.NONE);
		ctiBizStep.setText("BizStep");
		Composite compositeBizStep = new Composite(tabFolder, SWT.NONE);
		compositeBizStep.setLayout(new GridLayout());
		compositeBizStep.setLayoutData(new GridData(GridData.FILL_BOTH));
		ctiBizStep.setControl(compositeBizStep);

		
		CTabItem ctiTransType = new CTabItem(tabFolder, SWT.NONE);
		ctiTransType.setText("TranzType");
		Composite compositeTransType = new Composite(tabFolder, SWT.NONE);
		compositeTransType.setLayout(new GridLayout());
		compositeTransType.setLayoutData(new GridData(GridData.FILL_BOTH));
		ctiTransType.setControl(compositeTransType);

		
		//select the first tab at the beginning
		tabFolder.setSelection(ctiDisposition);
		
		
		
		createDispositionPart(compositeDisposition);
		
		composite.setSize(400, 600);
	}
	
	private void createDispositionPart(final Composite parent) {
		Composite buttonComposite = new Composite(parent,0);
		buttonComposite.setLayout(new GridLayout(3, false));
		buttonComposite.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		//add buttons
		Button buttonNew = new Button(buttonComposite, SWT.PUSH);
		buttonNew.setText("New");

		Button buttonDuplicate = new Button(buttonComposite, SWT.PUSH);
		buttonDuplicate.setText("Duplicate");
		
		Button buttonRemove = new Button(buttonComposite, SWT.PUSH);
		buttonRemove.setText("Remove");
		
		Composite listComposite = new Composite(parent,0);
		listComposite.setLayout(new GridLayout());
		listComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		
		Group dispositionGrp = new Group(listComposite, SWT.SHADOW_NONE);
		GridData dispositionGd = new GridData(SWT.FILL, SWT.FILL, true, true);
		dispositionGd.widthHint = 100;
		dispositionGrp.setLayoutData(dispositionGd);
		dispositionGrp.setText("Disposition");
		dispositionGrp.setLayout(new GridLayout());
		
		ListViewer listViewer = new ListViewer(dispositionGrp);
		listViewer.getControl().setLayoutData(
				new GridData(SWT.FILL, SWT.FILL, true, true));
	}

	
	private void createBizStepPart(final Composite parent) {}
	
	private void createTransTypePart(final Composite parent) {}
	
	@Override
	public void setFocus() {
		
	}

	@Override
	public String getContributorId() {
		return getSite().getId();
	}
}
