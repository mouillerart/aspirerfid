@javax.xml.bind.annotation.XmlSchema(namespace = "urn:epcglobal:ale:wsdl:1")
package org.ow2.aspirerfid.commons.ale.wsdl.ale;
