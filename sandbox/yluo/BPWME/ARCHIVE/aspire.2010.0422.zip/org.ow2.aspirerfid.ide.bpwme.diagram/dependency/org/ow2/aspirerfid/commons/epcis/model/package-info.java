@javax.xml.bind.annotation.XmlSchema(namespace = "urn:epcglobal:epcis-query:xsd:1")
package org.ow2.aspirerfid.commons.epcis.model;
