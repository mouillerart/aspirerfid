@javax.xml.bind.annotation.XmlSchema(namespace = "urn:epcglobal:xsd:1")
package org.ow2.aspirerfid.commons.epcglobal.commons;
