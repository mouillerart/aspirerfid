How to use the ASPIRE TCP Message Capturer
==============================================
type the command:

java -jar aspireTcpMessageCapturer-V0.1m-jar-with-dependencies.jar [Port Number]

e.g.: java -jar aspireTcpMessageCapturer-V0.1m-jar-with-dependencies.jar 8888
